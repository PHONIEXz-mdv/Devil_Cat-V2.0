<h1 align="center"> Devil_Cat-V2.0 </h1>
<p align="center">  
  
***
  
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=1BAFBAFF&center=true&width=910&height=100&lines=THANKS FOR CHOOSING ;Devil_Cat-V2.0;WHATSAPP+BUG+BOT;CREATED+BY+LORD+NO+NAME+MD;RELEASED+11.07.24" alt="Typing SVG" /></a>
  </p>

<img src= "https://telegra.ph/file/b94ebc14cfb758319e9f0.jpg" />
</p>

Devil Cat V2.0 BOT is a bug bot designed to enhance the functionality and preferences of a user's whatsApp. As well as put an end to the era of scammers. Use reasonably

If you clone my repo or use as base bot, dont forget to give credits. Lord No Name Rulez😶

1. Click on **[Fork](https://github.com/Anime-King01/Devil_Cat-V2.0/fork)** A must . Make sure to add a star 🌟 to encourage the developers.
   
**GET SESSION ID**
### GENERATE PAIR CODE FROM REPLIT
Fork the repl to get pair code for whatsApp
https://replit.com/@haotak/DevilCat-1?v=1

**DEPLOYMENT PROCESS**
### DEPLOY ON REPLIT
IF YOU DON'T HAVE A REPLIT ACCOUNT CREATE ONE AND DEPLOY 
    <br>
    <a href='https://replit.com/github/Anime-King01/Devil_Cat-V2.0' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Deploy-red?style=for-the-badge&logo=replit&logoColor=white'/></a>


### DEPLOYMENT ON TERMUX

**Go to your termux and input this commands**
termux-setup-storage

apt update

apt upgrade

pkg update && pkg upgrade

pkg install bash

pkg install libwebp

pkg install git -y

pkg install nodejs -y

pkg install ffmpeg -y 

pkg install wget

pkg install imagemagick -y


If you see any question while upgrading with this options with Y for yes or N for no = Click yes or y

If you see any question while upgrading with this options with Y or n for default, = Click n for Default

6. After its done upgrading type or copy and paste:

git clone  (copy and paste your forked repo not mine to save your changes) 

7. After that type: 

cd Devil_Cat-V2.0

8. after that type:

pkg install yarn

9. Then type:

yarn install 

10. After that type:

npm start 

11. It will ask you for your number type it with country code +
12. It will give you a pair code go and link it to your WhatsApp 
13. After linking
14. Bot Connected ⚡
15. Enjoy🤖

## Heroku Buildpack
```bash
heroku/nodejs
```
```
https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
```
```
https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```

*Add your Creds.json to Session file
* Create a new app at [Heroku](https://id.heroku.com/login)
* Add Build packs
* Connect your heroku with your github
* Locate Devil_Cat-V2.0
* Now deploy.
* Start the Worker
* Enjoy the Bot.
  
### 4. <a 
#### DEPLOY TO RENDER

 ★ Register To Render 
    <br>
<a href='https://dashboard.render.com/register' target="_blank"><img alt='Render' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=render' width="96.35" height="28"/></a></p>

★ Now Deploy
    <br>
<a href='https://dashboard.render.com/select-repo?type=web' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=render' width="96.35" height="28"/></a></p>

</br>

#### COPY THESE COMMANDS AND PASTE IF YOU TRYING TO DEPLOY [Devil_Cat-V2.0](https://github.com/Anime-King01/Devil_Cat-V2.0) ON ANY TERMINAL
```
sudo apt -y update && sudo apt -y upgrade
```
```
sudo apt -y install git ffmpeg curl
```
```
curl -fsSL https://deb.nodesource.com/setup_20.x -o nodesource_setup.sh
```
```
sudo -E bash nodesource_setup.sh
```
```
sudo apt-get install -y nodejs
```
```
sudo npm install -g yarn
```
```
sudo yarn global add pm2
```
```
git clone https://github.com/type-your-username-here/Devil_Cat-V2.0
```
```
cd Devil_Cat-V2.0
```
```
yarn install
```
```
npm start
```

### REPORT ISSUES

if you're having any issues message me on
WhatsApp: (https://wa.me/message/2DAGP33CWIDHD1) 

If the bot goes offline 
Just type cd and the bot name 
Then type npm start
It will come online



`Please Devil Cat V2.0 BOT is for scammers only. Don't use it to harm innocent people`


## Contributions

Contributions to Devil Cat V2.0 MD are welcome! If you have ideas for new features, improvements, or bug fixes, feel free to open an issue or submit a pull request. <br>

   thanks to these people ;

   **Xeon** who made the base bot

   **Re-Jeong** For helping me test it
   
   **Toxxic** for inspiration; <br>


## License

The WhatsApp Bot Devil Cat v2 MD is released under the [MIT License](https://opensource.org/licenses/MIT).

Enjoy the diverse features of the WhatsApp Bot Devil Cat v2 Md to enhance your conversations and make your WhatsApp experience more interesting!

## 🎯 Authors 🎯
  <div align="center">
  
| [![LORD NO NAME](https://github.com/Anime-King01.png?size=150)](https://github.com/Anime-King01) |
|----|
| [  LORD NO NAME ](https://github.com/Anime-King01) |
|  Developer |

  </div>
  <div align="center">
  
| [![BADBOI](https://github.com/BADBOI-v1.png?size=150)](https://github.com/BADBOI-v1) |
|----|
| [  BADBOI ](https://github.com/BADBOI-v1) |
|  Co-Developer |

  </div>
   
  </br> 

<h2 align="center">  Reminder
</h2>
   
- This bot is not made by `WhatsApp Inc.` So misusing the bot might `ban` your `WhatsApp account!`(Though your WhatsApp account can be unbanned only once.)
- I am not responsible for banning your account.
- Use at your own risk by keeping this warning in mind.
 
  
  
   ## `Special Thanks To`

* [`📕BADBOI..!!`](https://github.com/BADBOI-v1)

 
  
  
  
